# cc.Serializer

Transmit and receive Serial data and divide the stream into packets with NLSM protocol.

## Installation

```bash
pip install cc-serializer
```

## Usage

```python

```
